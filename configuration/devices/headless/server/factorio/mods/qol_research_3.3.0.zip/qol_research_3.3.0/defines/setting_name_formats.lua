return {
    infinite_research_enabled = 'qol-infinite-research-enabled',
    modpack_compatibility_enabled = 'qol-modpack-compatibility-enabled',
    research_enabled = 'qol-%s-research-enabled',
    flat_bonus = 'qol-%s-flat-bonus',
    multiplier = 'qol-%s-multiplier',
    effect_flag = 'qol-%s-field-%s',
    custom_config = 'qol-custom-config',
}
