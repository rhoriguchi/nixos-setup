require("prototypes.tips-and-tricks.1-angelsaddons-storage.1-angelsaddons-storage")
require("prototypes.tips-and-tricks.1-angelsaddons-storage.1-angelsaddons-storage-description")