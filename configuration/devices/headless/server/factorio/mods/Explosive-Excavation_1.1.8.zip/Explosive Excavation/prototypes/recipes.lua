data:extend({
  {
    type = "recipe",
    name = "blasting-charge",
    energy_required = 8,
    enabled = false,
    category = "crafting",
    ingredients =
    {
      {"cliff-explosives", 2},
      {"empty-barrel", 1}
    },
    result= "blasting-charge",
    result_count = 1
  }
})