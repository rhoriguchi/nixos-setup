# Train tunnels

Tunnels for trains

Very instable at the moment. Any help to stabilize it is appreciated.

####TODO
* fix all the cases of decoupling and hopefully remove the need to slow down trains
* fix transition between manual_mode and auto. move driver to previous controlLoco on auto->manual
* fix/replace the quadtree implementation ...
* mod configuration. resources on underground, diggy, max underground level
* editing trains that are partially in tunnels causes problems

 