data:extend({
    {
        type = "int-setting",
        name = "traintunnel-maxdepth",
        setting_type = "runtime-global",
        default_value = 1,
        minimum_value = 1,
        maximum_value = 255
    }
})