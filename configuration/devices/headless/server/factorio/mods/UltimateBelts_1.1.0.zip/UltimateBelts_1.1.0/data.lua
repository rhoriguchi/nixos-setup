
require("prototypes.items.ultimate-belt")
require("prototypes.items.ultra-fast-belt")
require("prototypes.items.extreme-fast-belt")
require("prototypes.items.ultra-express-belt")
require("prototypes.items.extreme-express-belt")

require("prototypes.items.ultimate-splitters")
require("prototypes.items.ultimate-underground-belts")
require("prototypes.recipes.ultimate-belt-recipes")
require("prototypes.recipes.ultimate-underground-belt-recipes")
require("prototypes.recipes.ultimate-splitter-recipes")
require("prototypes.technology.ultimate-belt-tech")

