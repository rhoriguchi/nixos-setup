Installation Instructions:
-Drop the provided zip into %appdata%/Factorio/mods
-You're done!

*make sure you're on appdata and not on the steamapps folder. 

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Hello! This is my first mod for Factorio. 
Gear Girl Character replaces the default character with a female version of the engineer.
Modelled and rendered in Blender, a free 3D modelling software. 

You can find me at:
youtube: https://www.youtube.com/c/sleepyengi | Factorio Mod portal: Sleepyengi | Twitter: @sleepyengi

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Future plans
-head improvements
-improvements to the gun running animation - might be difficult
-more saturation for the custom colors
-github source code
-better running animation 
-Thanks to Pi-C for helping me with code

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Have fun!

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~